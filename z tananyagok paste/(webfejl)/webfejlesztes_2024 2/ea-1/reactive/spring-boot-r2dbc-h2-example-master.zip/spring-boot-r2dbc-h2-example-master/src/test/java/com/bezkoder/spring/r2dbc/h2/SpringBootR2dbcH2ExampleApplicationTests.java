package com.bezkoder.spring.r2dbc.h2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootR2dbcH2ExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
