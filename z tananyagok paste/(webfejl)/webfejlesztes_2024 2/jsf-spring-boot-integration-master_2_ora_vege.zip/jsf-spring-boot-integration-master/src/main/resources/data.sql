insert into DEPARTMENT_MASTER values(1001,'IT'); 
insert into DEPARTMENT_MASTER values(1002,'Finance'); 
insert into DEPARTMENT_MASTER values(1003,'HR'); 
insert into DEPARTMENT_MASTER values(1004,'Operations');  

insert into EMP_INFO(emp_Id, EMP_NAME, PASSWORD, EMAIL_ID, DEPT_ID ) values(101,'Bharat','1234','bharat@email.com',1001);
insert into EMP_INFO(emp_Id, EMP_NAME, PASSWORD, EMAIL_ID, DEPT_ID ) values(103,'Singh','2345','singh@email.com',1002);
insert into EMP_INFO(emp_Id, EMP_NAME, PASSWORD, EMAIL_ID, DEPT_ID ) values(102,'xyz','3456','xyz@email.com',1003);
insert into EMP_INFO(emp_Id, EMP_NAME, PASSWORD, EMAIL_ID, DEPT_ID ) values(104,'shoaib','shoaib','shoaib@email.com',1004);