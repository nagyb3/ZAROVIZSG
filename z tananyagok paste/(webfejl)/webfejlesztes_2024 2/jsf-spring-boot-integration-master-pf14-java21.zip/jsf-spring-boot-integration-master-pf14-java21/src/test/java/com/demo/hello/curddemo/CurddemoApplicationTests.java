package com.demo.hello.curddemo;


//@RunWith(SpringRunner.class)
//@SpringBootTest
public class CurddemoApplicationTests {

    // @Test
    public void contextLoads() {
    }

}
