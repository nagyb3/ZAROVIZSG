package hu.unideb.inf.crud.utills;

public final class JsfSpringCurd {

	private JsfSpringCurd() {
		throw new IllegalStateException("Constant Class");
	}

	public static final String employeeNotFound = "EmployeeNotFound";

}